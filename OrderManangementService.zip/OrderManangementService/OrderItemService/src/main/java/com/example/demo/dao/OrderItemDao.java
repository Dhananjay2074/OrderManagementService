package com.example.demo.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.demo.entity.OrderItemEntity;
import com.example.demo.model.OrderItem;
import com.example.demo.repository.OrderItemRepository;

@Repository
public class OrderItemDao {
	@Autowired
	private OrderItemRepository orderRepository;

	public OrderItemEntity save(OrderItem item) {
		OrderItemEntity orderItemEntity=new OrderItemEntity();
		      orderItemEntity.setId(item.getId());
		      orderItemEntity.setProductCode(item.getProductCode());
		      orderItemEntity.setQuantity(item.getQuantity());
		      orderItemEntity.setProductName(item.getProductName());
		OrderItemEntity items=orderRepository.save(orderItemEntity);
		return items;
	}
	
}
