package com.example.demo.controller;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.demo.model.Order;
import com.example.demo.model.OrderItem;

@FeignClient(name = "OrdetItemService", url = "http://localhost:8081")
public interface OrderManagementClient {

	@PostMapping(value = "/createOrderItem")
	public ResponseEntity<OrderItem> createOrder(@RequestBody OrderItem orderItem) {
		
	}

}
