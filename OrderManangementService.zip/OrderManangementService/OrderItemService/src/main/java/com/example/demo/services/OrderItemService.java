package com.example.demo.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dao.OrderItemDao;
import com.example.demo.entity.OrderItemEntity;
import com.example.demo.model.OrderItem;

@Service
public class OrderItemService {

	@Autowired
	private OrderItemDao dao;

	public OrderItem createUserOrder(OrderItem orderItem) throws Exception {
		try {
			OrderItemEntity orderItemEntity = dao.save(orderItem);
			OrderItem item = new OrderItem();
			item.setId(orderItemEntity.getId());
			item.setProductName(orderItemEntity.getProductName());
			item.setProductCode(orderItemEntity.getProductCode());
			item.setQuantity(orderItemEntity.getQuantity());
			return item;
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		}

	}
}
