package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Order;
import com.example.demo.model.OrderItem;
import com.example.demo.services.OrderItemService;

import lombok.RequiredArgsConstructor;

@RestController
@RequiredArgsConstructor
public class OrderItemController {

  @Autowired
  private OrderItemService orderItemService;
	@PostMapping(value = "/createOrderItem")
	public ResponseEntity<OrderItem> createOrder(@RequestBody OrderItem orderItem) {
		try {
			OrderItem orderItem=orderItemService.createUserOrder(orderItem);
			return ResponseEntity<>(orderItem,HttpStatus.CREATED);
		}catch(Exception e) {
			return new ResponseEntity<>(null,HttpStatus.EXPECTATION_FAILED)
		}

		
	}
}
