package com.example.demo;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class WebServiceTest {

}
